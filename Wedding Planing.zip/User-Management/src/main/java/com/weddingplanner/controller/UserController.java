package com.weddingplanner.controller;

import com.weddingplanner.model.AdminUser;
import com.weddingplanner.model.RegularUser;
import com.weddingplanner.model.User;
import com.weddingplanner.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Show registration form
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new RegularUser());
        return "register";
    }

    // Process registration
    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") RegularUser user,
                               @RequestParam("weddingDateStr") String weddingDateStr,
                               RedirectAttributes redirectAttributes) {
        try {
            if (!weddingDateStr.isEmpty()) {
                user.setWeddingDate(LocalDate.parse(weddingDateStr));
            }

            boolean registered = userService.registerUser(user);
            if (registered) {
                redirectAttributes.addFlashAttribute("message", "Registration successful! Please login.");
                return "redirect:/users/login";
            } else {
                redirectAttributes.addFlashAttribute("error", "Registration failed. Email may already be in use.");
                return "redirect:/users/register";
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Registration failed: " + e.getMessage());
            return "redirect:/users/register";
        }
    }

    // Show login form
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    // Process login
    @PostMapping("/login")
    public String loginUser(@RequestParam("email") String email,
                            @RequestParam("password") String password,
                            HttpSession session,
                            RedirectAttributes redirectAttributes) {
        User user = userService.loginUser(email, password);
        if (user != null) {
            session.setAttribute("user", user);
            session.setAttribute("userId", user.getUserId());

            if (user instanceof AdminUser) {
                return "redirect:/users/admin/dashboard";
            } else {
                return "redirect:/users/profile";
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid email or password");
            return "redirect:/users/login";
        }
    }

    // Show user profile
    @GetMapping("/profile")
    public String showUserProfile(HttpSession session, Model model) {
        String userId = (String) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/users/login";
        }

        User user = userService.getUserById(userId);
        if (user == null) {
            session.invalidate();
            return "redirect:/users/login";
        }

        model.addAttribute("user", user);
        return "profile";
    }

    // Show edit profile form
    @GetMapping("/profile/edit")
    public String showEditProfileForm(HttpSession session, Model model) {
        String userId = (String) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/users/login";
        }

        User user = userService.getUserById(userId);
        if (user == null) {
            session.invalidate();
            return "redirect:/users/login";
        }

        model.addAttribute("user", user);
        return "edit-profile";
    }

    // Process profile update
    @PostMapping("/profile/update")
    public String updateProfile(HttpSession session,
                                @RequestParam("userId") String userId,
                                @RequestParam("email") String email,
                                @RequestParam("firstName") String firstName,
                                @RequestParam("lastName") String lastName,
                                @RequestParam("phoneNumber") String phoneNumber,
                                @RequestParam(value = "weddingDateStr", required = false) String weddingDateStr,
                                @RequestParam(value = "partnerName", required = false) String partnerName,
                                @RequestParam(value = "guestCount", required = false, defaultValue = "0") int guestCount,
                                @RequestParam(value = "weddingLocation", required = false) String weddingLocation,
                                @RequestParam(value = "role", required = false) String role,
                                @RequestParam(value = "department", required = false) String department,
                                @RequestParam(value = "securityKey", required = false) String securityKey,
                                @RequestParam("password") String password,
                                RedirectAttributes redirectAttributes) {

        String sessionUserId = (String) session.getAttribute("userId");
        if (sessionUserId == null || !sessionUserId.equals(userId)) {
            return "redirect:/users/login";
        }

        try {
            // Get the existing user to determine its type
            User existingUser = userService.getUserById(userId);
            if (existingUser == null) {
                redirectAttributes.addFlashAttribute("error", "User not found.");
                return "redirect:/users/profile";
            }

            User updatedUser;

            if (existingUser instanceof RegularUser) {
                RegularUser regularUser = new RegularUser();
                regularUser.setUserId(userId);
                regularUser.setEmail(email);
                regularUser.setPassword(password);
                regularUser.setFirstName(firstName);
                regularUser.setLastName(lastName);
                regularUser.setPhoneNumber(phoneNumber);
                regularUser.setRegistrationDate(existingUser.getRegistrationDate());

                if (weddingDateStr != null && !weddingDateStr.isEmpty()) {
                    regularUser.setWeddingDate(LocalDate.parse(weddingDateStr));
                } else {
                    regularUser.setWeddingDate(((RegularUser) existingUser).getWeddingDate());
                }

                regularUser.setPartnerName(partnerName);
                regularUser.setGuestCount(guestCount);
                regularUser.setWeddingLocation(weddingLocation);

                updatedUser = regularUser;
            } else if (existingUser instanceof AdminUser) {
                AdminUser adminUser = new AdminUser();
                adminUser.setUserId(userId);
                adminUser.setEmail(email);
                adminUser.setPassword(password);
                adminUser.setFirstName(firstName);
                adminUser.setLastName(lastName);
                adminUser.setPhoneNumber(phoneNumber);
                adminUser.setRegistrationDate(existingUser.getRegistrationDate());
                adminUser.setWeddingDate(existingUser.getWeddingDate());

                adminUser.setRole(role);
                adminUser.setDepartment(department);
                adminUser.setSecurityKey(securityKey);

                updatedUser = adminUser;
            } else {
                redirectAttributes.addFlashAttribute("error", "Invalid user type.");
                return "redirect:/users/profile";
            }

            boolean updated = userService.updateUserProfile(updatedUser);
            if (updated) {
                // Update the session with the new user data
                session.setAttribute("user", updatedUser);
                redirectAttributes.addFlashAttribute("message", "Profile updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Failed to update profile.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error updating profile: " + e.getMessage());
        }

        return "redirect:/users/profile";
    }

    // Delete account
    @PostMapping("/profile/delete")
    public String deleteAccount(HttpSession session, RedirectAttributes redirectAttributes) {
        String userId = (String) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/users/login";
        }

        boolean deleted = userService.deleteUserAccount(userId);
        if (deleted) {
            session.invalidate();
            redirectAttributes.addFlashAttribute("message", "Account deleted successfully.");
            return "redirect:/users/login";
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to delete account.");
            return "redirect:/users/profile";
        }
    }

    // Logout
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/users/login";
    }

    // Admin: User search
    @GetMapping("/admin/search")
    public String searchUsers(@RequestParam(value = "keyword", required = false) String keyword,
                              HttpSession session,
                              Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !(currentUser instanceof AdminUser)) {
            return "redirect:/users/login";
        }

        List<User> users = userService.searchUsers(keyword);
        model.addAttribute("users", users);
        model.addAttribute("keyword", keyword);
        return "admin-search";
    }

    // Admin: View user details
    @GetMapping("/admin/view/{userId}")
    public String viewUserDetails(@PathVariable("userId") String userId,
                                  HttpSession session,
                                  Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !(currentUser instanceof AdminUser)) {
            return "redirect:/users/login";
        }

        User user = userService.getUserById(userId);
        if (user == null) {
            return "redirect:/users/admin/search";
        }

        model.addAttribute("user", user);
        return "admin-view-user";
    }
}