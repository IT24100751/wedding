package com.weddingplanner.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

@Controller
public class CustomErrorController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        Object errorMessage = request.getAttribute(RequestDispatcher.ERROR_MESSAGE);
        Object exception = request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);

        model.addAttribute("status", status != null ? status : "Unknown");
        model.addAttribute("error", request.getAttribute(RequestDispatcher.ERROR_REQUEST_URI));
        model.addAttribute("message", errorMessage != null ? errorMessage : "No error message available");

        if (exception != null && exception instanceof Exception) {
            Exception ex = (Exception) exception;
            StringBuilder stackTrace = new StringBuilder();
            stackTrace.append(ex.getMessage()).append("\n");
            for (StackTraceElement element : ex.getStackTrace()) {
                stackTrace.append(element.toString()).append("\n");
            }
            model.addAttribute("trace", stackTrace.toString());
        }

        return "error";
    }
}