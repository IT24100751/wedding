package com.weddingplanner.service;

import com.weddingplanner.model.User;
import java.util.List;

public interface UserService {
    boolean registerUser(User user);
    User loginUser(String email, String password);
    User getUserById(String userId);
    User getUserByEmail(String email);
    List<User> getAllUsers();
    boolean updateUserProfile(User user);
    boolean deleteUserAccount(String userId);
    List<User> searchUsers(String keyword);
}