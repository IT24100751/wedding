package com.weddingplanner.service;

import com.weddingplanner.model.User;
import com.weddingplanner.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public boolean registerUser(User user) {
        // Generate a unique ID if not provided
        if (user.getUserId() == null || user.getUserId().isEmpty()) {
            user.setUserId(UUID.randomUUID().toString());
        }

        // Validate user data
        if (!isValidUser(user)) {
            logger.error("Invalid user data for registration: {}", user.getEmail());
            return false;
        }

        logger.info("Registering new user: {}", user.getEmail());
        return userRepository.saveUser(user);
    }

    @Override
    public User loginUser(String email, String password) {
        logger.info("Attempting login for user: {}", email);
        User user = userRepository.findUserByEmail(email);
        if (user != null && user.authenticate(password)) {
            logger.info("Login successful for user: {}", email);
            return user;
        }
        logger.warn("Login failed for user: {}", email);
        return null;
    }

    @Override
    public User getUserById(String userId) {
        logger.info("Getting user by ID: {}", userId);
        return userRepository.findUserById(userId);
    }

    @Override
    public User getUserByEmail(String email) {
        logger.info("Getting user by email: {}", email);
        return userRepository.findUserByEmail(email);
    }

    @Override
    public List<User> getAllUsers() {
        logger.info("Getting all users");
        return userRepository.findAllUsers();
    }

    @Override
    public boolean updateUserProfile(User user) {
        // Validate user exists
        logger.info("Updating profile for user ID: {}", user.getUserId());
        User existingUser = userRepository.findUserById(user.getUserId());
        if (existingUser == null) {
            logger.error("User not found for update: {}", user.getUserId());
            return false;
        }

        // Validate user data
        if (!isValidUser(user)) {
            logger.error("Invalid user data for update: {}", user.getEmail());
            return false;
        }

        logger.info("User data validated, proceeding with update");
        boolean result = userRepository.updateUser(user);
        if (result) {
            logger.info("Profile updated successfully for user: {}", user.getEmail());
        } else {
            logger.error("Failed to update profile for user: {}", user.getEmail());
        }
        return result;
    }

    @Override
    public boolean deleteUserAccount(String userId) {
        // Validate user exists
        logger.info("Deleting account for user ID: {}", userId);
        User existingUser = userRepository.findUserById(userId);
        if (existingUser == null) {
            logger.error("User not found for deletion: {}", userId);
            return false;
        }

        boolean result = userRepository.deleteUser(userId);
        if (result) {
            logger.info("Account deleted successfully for user ID: {}", userId);
        } else {
            logger.error("Failed to delete account for user ID: {}", userId);
        }
        return result;
    }

    @Override
    public List<User> searchUsers(String keyword) {
        logger.info("Searching users with keyword: {}", keyword);
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllUsers();
        }

        String searchTerm = keyword.toLowerCase();
        return userRepository.findAllUsers().stream()
                .filter(user ->
                        user.getFirstName().toLowerCase().contains(searchTerm) ||
                                user.getLastName().toLowerCase().contains(searchTerm) ||
                                user.getEmail().toLowerCase().contains(searchTerm))
                .collect(Collectors.toList());
    }

    private boolean isValidUser(User user) {
        boolean isValid = user != null &&
                user.getEmail() != null && !user.getEmail().isEmpty() &&
                user.getPassword() != null && !user.getPassword().isEmpty() &&
                user.getFirstName() != null && !user.getFirstName().isEmpty() &&
                user.getLastName() != null && !user.getLastName().isEmpty();

        if (!isValid) {
            logger.warn("User validation failed: email={}, firstName={}, lastName={}",
                    user != null ? user.getEmail() : "null",
                    user != null ? user.getFirstName() : "null",
                    user != null ? user.getLastName() : "null");
        }

        return isValid;
    }
}