package com.weddingplanner.repository;

import com.weddingplanner.model.User;
import java.util.List;

public interface UserRepository {
    boolean saveUser(User user);
    User findUserById(String userId);
    User findUserByEmail(String email);
    List<User> findAllUsers();
    boolean updateUser(User user);
    boolean deleteUser(String userId);
}