package com.weddingplanner.repository;

import com.weddingplanner.model.AdminUser;
import com.weddingplanner.model.RegularUser;
import com.weddingplanner.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class UserRepositoryImpl implements UserRepository {
    private static final Logger logger = LoggerFactory.getLogger(UserRepositoryImpl.class);
    private static final String USERS_FILE = "src/main/resources/data/users.txt";

    public UserRepositoryImpl() {
        // Create directory and file if they don't exist
        try {
            Files.createDirectories(Paths.get("src/main/resources/data"));
            File file = new File(USERS_FILE);
            if (!file.exists()) {
                file.createNewFile();
                logger.info("Created new users file at: {}", USERS_FILE);
            } else {
                logger.info("Using existing users file at: {}", USERS_FILE);
            }
        } catch (IOException e) {
            logger.error("Error initializing users file: {}", e.getMessage(), e);
        }
    }

    @Override
    public boolean saveUser(User user) {
        List<User> users = findAllUsers();

        // Check if user already exists
        if (users.stream().anyMatch(u -> u.getUserId().equals(user.getUserId()) ||
                u.getEmail().equals(user.getEmail()))) {
            logger.warn("User already exists with ID: {} or email: {}", user.getUserId(), user.getEmail());
            return false;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE, true))) {
            String userString = user.toFileString();
            logger.debug("Saving user: {}", userString);
            writer.write(userString);
            writer.newLine();
            logger.info("User saved successfully: {}", user.getEmail());
            return true;
        } catch (IOException e) {
            logger.error("Error saving user: {}", e.getMessage(), e);
            return false;
        }
    }

    @Override
    public User findUserById(String userId) {
        logger.debug("Finding user by ID: {}", userId);
        return findAllUsers().stream()
                .filter(user -> user.getUserId().equals(userId))
                .findFirst()
                .orElse(null);
    }

    @Override
    public User findUserByEmail(String email) {
        logger.debug("Finding user by email: {}", email);
        return findAllUsers().stream()
                .filter(user -> user.getEmail().equals(email))
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<User> findAllUsers() {
        List<User> users = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (!line.trim().isEmpty()) {
                    try {
                        User user = parseUserFromLine(line);
                        if (user != null) {
                            users.add(user);
                        } else {
                            logger.warn("Could not parse user from line {}: {}", lineNumber, line);
                        }
                    } catch (Exception e) {
                        logger.error("Error parsing user at line {}: {}", lineNumber, e.getMessage(), e);
                    }
                }
            }
            logger.debug("Found {} users in file", users.size());
        } catch (IOException e) {
            logger.error("Error reading users file: {}", e.getMessage(), e);
        }
        return users;
    }

    @Override
    public boolean updateUser(User user) {
        logger.info("Updating user: {}", user.getUserId());
        List<User> users = findAllUsers();
        boolean userExists = users.stream().anyMatch(u -> u.getUserId().equals(user.getUserId()));

        if (!userExists) {
            logger.warn("User not found for update: {}", user.getUserId());
            return false;
        }

        List<User> updatedUsers = users.stream()
                .map(u -> u.getUserId().equals(user.getUserId()) ? user : u)
                .collect(Collectors.toList());

        boolean result = writeAllUsers(updatedUsers);
        if (result) {
            logger.info("User updated successfully: {}", user.getUserId());
        } else {
            logger.error("Failed to update user: {}", user.getUserId());
        }
        return result;
    }

    @Override
    public boolean deleteUser(String userId) {
        logger.info("Deleting user: {}", userId);
        List<User> users = findAllUsers();
        boolean userExists = users.stream().anyMatch(u -> u.getUserId().equals(userId));

        if (!userExists) {
            logger.warn("User not found for deletion: {}", userId);
            return false;
        }

        List<User> remainingUsers = users.stream()
                .filter(user -> !user.getUserId().equals(userId))
                .collect(Collectors.toList());

        boolean result = writeAllUsers(remainingUsers);
        if (result) {
            logger.info("User deleted successfully: {}", userId);
        } else {
            logger.error("Failed to delete user: {}", userId);
        }
        return result;
    }

    private boolean writeAllUsers(List<User> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE, false))) {
            for (User user : users) {
                writer.write(user.toFileString());
                writer.newLine();
            }
            logger.debug("Wrote {} users to file", users.size());
            return true;
        } catch (IOException e) {
            logger.error("Error writing users to file: {}", e.getMessage(), e);
            return false;
        }
    }

    private User parseUserFromLine(String line) {
        String[] parts = line.split(",");
        if (parts.length < 9) {
            logger.warn("Invalid user data format, expected at least 9 parts but got {}: {}", parts.length, line);
            return null;
        }

        try {
            String userId = parts[0];
            String email = parts[1];
            String password = parts[2];
            String firstName = parts[3];
            String lastName = parts[4];
            String phoneNumber = parts[5];
            LocalDate weddingDate = parts[6].equals("null") ? null : LocalDate.parse(parts[6]);
            LocalDate registrationDate = LocalDate.parse(parts[7]);
            String userType = parts[8];

            User user;
            if ("RegularUser".equals(userType)) {
                if (parts.length < 12) {
                    logger.warn("Invalid RegularUser data format, expected at least 12 parts but got {}: {}", parts.length, line);
                    return null;
                }

                String partnerName = parts[9];
                int guestCount = Integer.parseInt(parts[10]);
                String weddingLocation = parts[11];

                user = new RegularUser(userId, email, password, firstName, lastName, phoneNumber,
                        weddingDate, partnerName, guestCount, weddingLocation);
            } else if ("AdminUser".equals(userType)) {
                if (parts.length < 12) {
                    logger.warn("Invalid AdminUser data format, expected at least 12 parts but got {}: {}", parts.length, line);
                    return null;
                }

                String role = parts[9];
                String department = parts[10];
                String securityKey = parts[11];

                user = new AdminUser(userId, email, password, firstName, lastName, phoneNumber,
                        weddingDate, role, department, securityKey);
            } else {
                logger.warn("Unknown user type: {}", userType);
                return null;
            }

            user.setRegistrationDate(registrationDate);
            return user;
        } catch (Exception e) {
            logger.error("Error parsing user data: {}", e.getMessage(), e);
            return null;
        }
    }
}