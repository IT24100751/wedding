package com.weddingplanner.model;

import java.time.LocalDate;

// Inheritance: AdminUser extends User
public class AdminUser extends User {
    private String role;
    private String department;
    private String securityKey;

    public AdminUser() {
        super();
    }

    public AdminUser(String userId, String email, String password, String firstName, String lastName,
                     String phoneNumber, LocalDate weddingDate, String role, String department, String securityKey) {
        super(userId, email, password, firstName, lastName, phoneNumber, weddingDate);
        this.role = role;
        this.department = department;
        this.securityKey = securityKey;
    }

    // Polymorphism: Different authentication implementation with additional security
    @Override
    public boolean authenticate(String password) {
        // Admin requires both password and security key validation
        return getPassword().equals(password) && this.securityKey != null && !this.securityKey.isEmpty();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSecurityKey() {
        return securityKey;
    }

    public void setSecurityKey(String securityKey) {
        this.securityKey = securityKey;
    }

    @Override
    public String toFileString() {
        return super.toFileString() + "," + role + "," + department + "," + securityKey;
    }
}