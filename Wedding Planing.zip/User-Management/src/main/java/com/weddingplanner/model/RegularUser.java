package com.weddingplanner.model;

import java.time.LocalDate;

// Inheritance: RegularUser extends User
public class RegularUser extends User {
    private String partnerName;
    private int guestCount;
    private String weddingLocation;

    public RegularUser() {
        super();
    }

    public RegularUser(String userId, String email, String password, String firstName, String lastName,
                       String phoneNumber, LocalDate weddingDate, String partnerName,
                       int guestCount, String weddingLocation) {
        super(userId, email, password, firstName, lastName, phoneNumber, weddingDate);
        this.partnerName = partnerName;
        this.guestCount = guestCount;
        this.weddingLocation = weddingLocation;
    }

    // Polymorphism: Different authentication implementation
    @Override
    public boolean authenticate(String password) {
        return getPassword().equals(password);
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public int getGuestCount() {
        return guestCount;
    }

    public void setGuestCount(int guestCount) {
        this.guestCount = guestCount;
    }

    public String getWeddingLocation() {
        return weddingLocation;
    }

    public void setWeddingLocation(String weddingLocation) {
        this.weddingLocation = weddingLocation;
    }

    @Override
    public String toFileString() {
        return super.toFileString() + "," + partnerName + "," + guestCount + "," + weddingLocation;
    }
}