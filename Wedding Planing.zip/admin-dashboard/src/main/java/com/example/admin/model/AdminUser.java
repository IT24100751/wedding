package com.example.admin.model;

// Inheritance: AdminUser extends User
public class AdminUser extends User {
    private String role;
    private boolean superAdmin;

    public AdminUser() {
        super();
    }

    public AdminUser(int id, String username, String password, String email, String createdAt, 
                    String role, boolean superAdmin) {
        super(id, username, password, email, createdAt);
        this.role = role;
        this.superAdmin = superAdmin;
    }

    // Getters and Setters
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isSuperAdmin() {
        return superAdmin;
    }

    public void setSuperAdmin(boolean superAdmin) {
        this.superAdmin = superAdmin;
    }

    @Override
    public String toString() {
        return super.toString() + "," + role + "," + superAdmin;
    }
}
