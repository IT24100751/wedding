package com.example.admin.model;

public class Vendor {
    private int id;
    private String name;
    private String description;
    private String category;
    private double rating;
    private int bookingCount;
    private String createdAt;

    public Vendor() {
        // Default constructor
        this.rating = 0.0;
        this.bookingCount = 0;
    }

    public Vendor(int id, String name, String description, String category, 
                 double rating, int bookingCount, String createdAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.rating = rating;
        this.bookingCount = bookingCount;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getBookingCount() {
        return bookingCount;
    }

    public void setBookingCount(int bookingCount) {
        this.bookingCount = bookingCount;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return id + "," + name + "," + description + "," + category + "," + 
               rating + "," + bookingCount + "," + createdAt;
    }
}
