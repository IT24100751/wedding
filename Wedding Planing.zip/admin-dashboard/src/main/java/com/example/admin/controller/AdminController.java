package com.example.admin.controller;

import com.example.admin.model.*;
import com.example.admin.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        // Statistics
        model.addAttribute("totalUsers", adminService.getTotalUsers());
        model.addAttribute("totalVendors", adminService.getTotalVendors());
        model.addAttribute("totalBookings", adminService.getTotalBookings());
        model.addAttribute("totalReviews", adminService.getTotalReviews());
        
        // Top vendors
        model.addAttribute("topBookedVendors", adminService.getTopBookedVendors(5));
        model.addAttribute("topRatedVendors", adminService.getTopRatedVendors(5));
        
        return "admin/dashboard";
    }

    // Admin Users
    @GetMapping("/admins")
    public String listAdmins(Model model) {
        model.addAttribute("admins", adminService.getAllAdmins());
        return "admin/admins";
    }

    @GetMapping("/admins/new")
    public String newAdminForm(Model model) {
        model.addAttribute("admin", new AdminUser());
        return "admin/admin-form";
    }

    @PostMapping("/admins/save")
    public String saveAdmin(@ModelAttribute AdminUser admin, RedirectAttributes redirectAttributes) {
        adminService.createAdmin(admin);
        redirectAttributes.addFlashAttribute("message", "Admin user created successfully!");
        return "redirect:/admin/admins";
    }

    // Vendors
    @GetMapping("/vendors")
    public String listVendors(Model model) {
        List<Vendor> vendors = adminService.getAllVendors();
        System.out.println("Found " + vendors.size() + " vendors");
        model.addAttribute("vendors", vendors);
        return "admin/vendors";
    }

    @GetMapping("/vendors/new")
    public String newVendorForm(Model model) {
        model.addAttribute("vendor", new Vendor());
        return "admin/vendor-new";
    }

    @PostMapping("/vendors/save")
    public String saveVendor(@ModelAttribute Vendor vendor, RedirectAttributes redirectAttributes) {
        System.out.println("Saving vendor: " + vendor.getName());
        adminService.createVendor(vendor);
        redirectAttributes.addFlashAttribute("message", "Vendor created successfully!");
        return "redirect:/admin/vendors";
    }

    @GetMapping("/vendors/edit/{id}")
    public String editVendorForm(@PathVariable int id, Model model) {
        Vendor vendor = adminService.getVendorById(id);
        model.addAttribute("vendor", vendor);
        return "admin/vendor-form";
    }

    @PostMapping("/vendors/update")
    public String updateVendor(@ModelAttribute Vendor vendor, RedirectAttributes redirectAttributes) {
        adminService.updateVendor(vendor);
        redirectAttributes.addFlashAttribute("message", "Vendor updated successfully!");
        return "redirect:/admin/vendors";
    }

    @GetMapping("/vendors/delete/{id}")
    public String deleteVendor(@PathVariable int id, RedirectAttributes redirectAttributes) {
        if (adminService.deleteVendor(id)) {
            redirectAttributes.addFlashAttribute("message", "Vendor deleted successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to delete vendor!");
        }
        return "redirect:/admin/vendors";
    }

    // Reviews
    @GetMapping("/reviews")
    public String listReviews(Model model) {
        model.addAttribute("reviews", adminService.getAllReviews());
        return "admin/reviews";
    }

    @GetMapping("/reviews/new")
    public String newReviewForm(Model model) {
        List<Vendor> vendors = adminService.getAllVendors();
        System.out.println("Found " + vendors.size() + " vendors for review form");
        model.addAttribute("review", new Review());
        model.addAttribute("vendors", vendors);
        return "admin/review-form";
    }

    @PostMapping("/reviews/save")
    public String saveReview(@ModelAttribute Review review, RedirectAttributes redirectAttributes) {
        adminService.createReview(review);
        redirectAttributes.addFlashAttribute("message", "Review created successfully!");
        return "redirect:/admin/reviews";
    }

    @GetMapping("/reviews/delete/{id}")
    public String deleteReview(@PathVariable int id, RedirectAttributes redirectAttributes) {
        if (adminService.deleteReview(id)) {
            redirectAttributes.addFlashAttribute("message", "Review deleted successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to delete review!");
        }
        return "redirect:/admin/reviews";
    }

    // Bookings
    @GetMapping("/bookings")
    public String listBookings(Model model) {
        model.addAttribute("bookings", adminService.getAllBookings());
        return "admin/bookings";
    }

    @GetMapping("/bookings/new")
    public String newBookingForm(Model model) {
        List<Vendor> vendors = adminService.getAllVendors();
        System.out.println("Found " + vendors.size() + " vendors for booking form");
        model.addAttribute("booking", new Booking());
        model.addAttribute("vendors", vendors);
        return "admin/booking-form";
    }

    @PostMapping("/bookings/save")
    public String saveBooking(@ModelAttribute Booking booking, RedirectAttributes redirectAttributes) {
        adminService.createBooking(booking);
        redirectAttributes.addFlashAttribute("message", "Booking created successfully!");
        return "redirect:/admin/bookings";
    }

    @GetMapping("/bookings/delete/{id}")
    public String deleteBooking(@PathVariable int id, RedirectAttributes redirectAttributes) {
        if (adminService.deleteBooking(id)) {
            redirectAttributes.addFlashAttribute("message", "Booking deleted successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to delete booking!");
        }
        return "redirect:/admin/bookings";
    }
}
