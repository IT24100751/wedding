package com.example.admin.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.File;

@Configuration
@PropertySource("classpath:application.properties")
public class AppConfig {

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public void ensureDataDirectoryExists() {
        String dataDir = "src/main/resources/data/";
        File directory = new File(dataDir);
        if (!directory.exists()) {
            boolean created = directory.mkdirs();
            System.out.println("Data directory created: " + created);
        } else {
            System.out.println("Data directory already exists");
        }
    }
}
