package com.example.admin.service;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Service;

@Service
public class FileService {
    private static final String DATA_DIR = "src/main/resources/data/";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Ensure data directory exists
    public FileService() {
        File directory = new File(DATA_DIR);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }

    // Read all lines from a file
    public List<String> readLines(String fileName) {
        try {
            Path path = Paths.get(DATA_DIR + fileName);
            if (!Files.exists(path)) {
                Files.createFile(path);
                return new ArrayList<>();
            }
            return Files.readAllLines(path);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error reading file: " + fileName + " - " + e.getMessage());
            return new ArrayList<>();
        }
    }

    // Write lines to a file
    public void writeLines(String fileName, List<String> lines) {
        try {
            Path path = Paths.get(DATA_DIR + fileName);
            if (!Files.exists(path)) {
                Files.createFile(path);
            }
            Files.write(path, lines);
            System.out.println("Successfully wrote " + lines.size() + " lines to " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error writing to file: " + fileName + " - " + e.getMessage());
        }
    }

    // Append a line to a file
    public void appendLine(String fileName, String line) {
        try {
            Path path = Paths.get(DATA_DIR + fileName);
            if (!Files.exists(path)) {
                Files.createFile(path);
            }
            Files.write(path, Collections.singletonList(line), StandardOpenOption.APPEND);
            System.out.println("Successfully appended line to " + fileName + ": " + line);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error appending to file: " + fileName + " - " + e.getMessage());
        }
    }

    // Get current timestamp
    public String getCurrentTimestamp() {
        return LocalDateTime.now().format(DATE_FORMATTER);
    }

    // Get next ID for a file
    public int getNextId(String fileName) {
        List<String> lines = readLines(fileName);
        if (lines.isEmpty()) {
            return 1;
        }
        
        int maxId = 0;
        for (String line : lines) {
            if (!line.isEmpty()) {
                try {
                    int id = Integer.parseInt(line.split(",")[0]);
                    if (id > maxId) {
                        maxId = id;
                    }
                } catch (Exception e) {
                    // Skip invalid lines
                }
            }
        }
        return maxId + 1;
    }
}
