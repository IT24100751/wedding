package com.example.admin.service;

import com.example.admin.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AdminService {
    private static final String ADMIN_FILE = "admin_users.txt";
    private static final String USER_FILE = "users.txt";
    private static final String VENDOR_FILE = "vendors.txt";
    private static final String BOOKING_FILE = "bookings.txt";
    private static final String REVIEW_FILE = "reviews.txt";

    @Autowired
    private FileService fileService;

    // Admin User Operations
    public List<AdminUser> getAllAdmins() {
        List<String> lines = fileService.readLines(ADMIN_FILE);
        List<AdminUser> admins = new ArrayList<>();
        
        for (String line : lines) {
            if (!line.isEmpty()) {
                String[] parts = line.split(",");
                if (parts.length >= 7) {
                    AdminUser admin = new AdminUser(
                        Integer.parseInt(parts[0]),
                        parts[1],
                        parts[2],
                        parts[3],
                        parts[4],
                        parts[5],
                        Boolean.parseBoolean(parts[6])
                    );
                    admins.add(admin);
                }
            }
        }
        return admins;
    }

    public AdminUser getAdminById(int id) {
        return getAllAdmins().stream()
                .filter(admin -> admin.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public AdminUser createAdmin(AdminUser admin) {
        int id = fileService.getNextId(ADMIN_FILE);
        admin.setId(id);
        admin.setCreatedAt(fileService.getCurrentTimestamp());
        
        fileService.appendLine(ADMIN_FILE, admin.toString());
        return admin;
    }

    // User Statistics
    public int getTotalUsers() {
        return fileService.readLines(USER_FILE).size();
    }

    // Vendor Operations
    public List<Vendor> getAllVendors() {
        List<String> lines = fileService.readLines(VENDOR_FILE);
        List<Vendor> vendors = new ArrayList<>();
        
        System.out.println("Reading vendors from file, found " + lines.size() + " lines");
        
        for (String line : lines) {
            if (!line.isEmpty()) {
                try {
                    String[] parts = line.split(",");
                    if (parts.length >= 7) {
                        Vendor vendor = new Vendor(
                            Integer.parseInt(parts[0]),
                            parts[1],
                            parts[2],
                            parts[3],
                            Double.parseDouble(parts[4]),
                            Integer.parseInt(parts[5]),
                            parts[6]
                        );
                        vendors.add(vendor);
                        System.out.println("Loaded vendor: " + vendor.getId() + " - " + vendor.getName());
                    } else {
                        System.out.println("Invalid vendor line format: " + line);
                    }
                } catch (Exception e) {
                    System.out.println("Error parsing vendor line: " + line + " - " + e.getMessage());
                }
            }
        }
        return vendors;
    }

    public int getTotalVendors() {
        return getAllVendors().size();
    }

    public Vendor getVendorById(int id) {
        return getAllVendors().stream()
                .filter(vendor -> vendor.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public Vendor updateVendor(Vendor updatedVendor) {
        List<Vendor> vendors = getAllVendors();
        List<String> lines = new ArrayList<>();
        
        for (Vendor vendor : vendors) {
            if (vendor.getId() == updatedVendor.getId()) {
                // Preserve booking count and rating
                updatedVendor.setBookingCount(vendor.getBookingCount());
                updatedVendor.setRating(vendor.getRating());
                updatedVendor.setCreatedAt(vendor.getCreatedAt());
                lines.add(updatedVendor.toString());
            } else {
                lines.add(vendor.toString());
            }
        }
        
        fileService.writeLines(VENDOR_FILE, lines);
        return updatedVendor;
    }

    public boolean deleteVendor(int id) {
        List<Vendor> vendors = getAllVendors();
        List<String> lines = vendors.stream()
                .filter(vendor -> vendor.getId() != id)
                .map(Vendor::toString)
                .collect(Collectors.toList());
        
        if (lines.size() < vendors.size()) {
            fileService.writeLines(VENDOR_FILE, lines);
            return true;
        }
        return false;
    }

    // Booking Operations
    public List<Booking> getAllBookings() {
        List<String> lines = fileService.readLines(BOOKING_FILE);
        List<Booking> bookings = new ArrayList<>();
        
        for (String line : lines) {
            if (!line.isEmpty()) {
                try {
                    String[] parts = line.split(",");
                    if (parts.length >= 6) {
                        Booking booking = new Booking(
                            Integer.parseInt(parts[0]),
                            Integer.parseInt(parts[1]),
                            Integer.parseInt(parts[2]),
                            parts[3],
                            parts[4],
                            parts[5]
                        );
                        bookings.add(booking);
                    }
                } catch (Exception e) {
                    System.out.println("Error parsing booking line: " + line + " - " + e.getMessage());
                }
            }
        }
        return bookings;
    }

    public int getTotalBookings() {
        return getAllBookings().size();
    }

    // Review Operations
    public List<Review> getAllReviews() {
        List<String> lines = fileService.readLines(REVIEW_FILE);
        List<Review> reviews = new ArrayList<>();
        
        for (String line : lines) {
            if (!line.isEmpty()) {
                try {
                    String[] parts = line.split(",");
                    if (parts.length >= 6) {
                        Review review = new Review(
                            Integer.parseInt(parts[0]),
                            Integer.parseInt(parts[1]),
                            Integer.parseInt(parts[2]),
                            Integer.parseInt(parts[3]),
                            parts[4],
                            parts[5]
                        );
                        reviews.add(review);
                    }
                } catch (Exception e) {
                    System.out.println("Error parsing review line: " + line + " - " + e.getMessage());
                }
            }
        }
        return reviews;
    }

    public int getTotalReviews() {
        return getAllReviews().size();
    }

    public boolean deleteReview(int id) {
        List<Review> reviews = getAllReviews();
        int vendorId = -1;
        
        // Find the vendor ID before deleting
        for (Review review : reviews) {
            if (review.getId() == id) {
                vendorId = review.getVendorId();
                break;
            }
        }
        
        List<String> lines = reviews.stream()
                .filter(review -> review.getId() != id)
                .map(Review::toString)
                .collect(Collectors.toList());
        
        if (lines.size() < reviews.size() && vendorId != -1) {
            fileService.writeLines(REVIEW_FILE, lines);
            // Update vendor rating
            updateVendorRating(vendorId);
            return true;
        }
        return false;
    }

    // Dashboard Statistics
    public List<Vendor> getTopBookedVendors(int limit) {
        List<Vendor> vendors = getAllVendors();
        if (vendors.isEmpty()) {
            return new ArrayList<>();
        }
        
        return vendors.stream()
                .sorted(Comparator.comparing(Vendor::getBookingCount).reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }

    public List<Vendor> getTopRatedVendors(int limit) {
        List<Vendor> vendors = getAllVendors();
        if (vendors.isEmpty()) {
            return new ArrayList<>();
        }
        
        return vendors.stream()
                .sorted(Comparator.comparing(Vendor::getRating).reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }

    // Add methods for creating vendors, bookings, and reviews

    // Vendor creation
    public Vendor createVendor(Vendor vendor) {
        int id = fileService.getNextId(VENDOR_FILE);
        vendor.setId(id);
        vendor.setCreatedAt(fileService.getCurrentTimestamp());
        vendor.setBookingCount(0);
        vendor.setRating(0.0);
        
        String vendorLine = vendor.toString();
        System.out.println("Creating vendor: " + vendorLine);
        fileService.appendLine(VENDOR_FILE, vendorLine);
        return vendor;
    }

    // Booking operations
    public Booking createBooking(Booking booking) {
        int id = fileService.getNextId(BOOKING_FILE);
        booking.setId(id);
        booking.setCreatedAt(fileService.getCurrentTimestamp());
        
        fileService.appendLine(BOOKING_FILE, booking.toString());
        
        // Update vendor booking count
        updateVendorBookingCount(booking.getVendorId());
        
        return booking;
    }

    public boolean deleteBooking(int id) {
        List<Booking> bookings = getAllBookings();
        int vendorId = -1;
        
        // Find the vendor ID before deleting
        for (Booking booking : bookings) {
            if (booking.getId() == id) {
                vendorId = booking.getVendorId();
                break;
            }
        }
        
        List<String> lines = bookings.stream()
                .filter(booking -> booking.getId() != id)
                .map(Booking::toString)
                .collect(Collectors.toList());
        
        if (lines.size() < bookings.size() && vendorId != -1) {
            fileService.writeLines(BOOKING_FILE, lines);
            // Update vendor booking count
            updateVendorBookingCount(vendorId);
            return true;
        }
        return false;
    }

    private void updateVendorBookingCount(int vendorId) {
        List<Booking> bookings = getAllBookings();
        long count = bookings.stream()
                .filter(b -> b.getVendorId() == vendorId)
                .count();
        
        Vendor vendor = getVendorById(vendorId);
        if (vendor != null) {
            vendor.setBookingCount((int) count);
            updateVendor(vendor);
        }
    }

    // Review operations
    public Review createReview(Review review) {
        int id = fileService.getNextId(REVIEW_FILE);
        review.setId(id);
        review.setCreatedAt(fileService.getCurrentTimestamp());
        
        fileService.appendLine(REVIEW_FILE, review.toString());
        
        // Update vendor rating
        updateVendorRating(review.getVendorId());
        
        return review;
    }

    private void updateVendorRating(int vendorId) {
        List<Review> reviews = getAllReviews();
        List<Review> vendorReviews = reviews.stream()
                .filter(r -> r.getVendorId() == vendorId)
                .collect(Collectors.toList());
        
        if (!vendorReviews.isEmpty()) {
            double avgRating = vendorReviews.stream()
                    .mapToInt(Review::getRating)
                    .average()
                    .orElse(0.0);
        
            Vendor vendor = getVendorById(vendorId);
            if (vendor != null) {
                vendor.setRating(Math.round(avgRating * 10.0) / 10.0); // Round to 1 decimal place
                updateVendor(vendor);
            }
        }
    }
}
