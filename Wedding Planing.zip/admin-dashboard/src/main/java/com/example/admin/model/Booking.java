package com.example.admin.model;

public class Booking {
    private int id;
    private int userId;
    private int vendorId;
    private String bookingDate;
    private String status;
    private String createdAt;

    public Booking() {
    }

    public Booking(int id, int userId, int vendorId, String bookingDate, String status, String createdAt) {
        this.id = id;
        this.userId = userId;
        this.vendorId = vendorId;
        this.bookingDate = bookingDate;
        this.status = status;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getVendorId() {
        return vendorId;
    }

    public void setVendorId(int vendorId) {
        this.vendorId = vendorId;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return id + "," + userId + "," + vendorId + "," + bookingDate + "," + status + "," + createdAt;
    }
}
