package com.example.bookingmanagement.util;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Collections;

import org.springframework.stereotype.Component;

@Component
public class FileHandler {

    public void writeToFile(String filePath, List<String> lines) throws IOException {
        Path path = Paths.get(filePath);

        // Create parent directories if they don't exist
        Files.createDirectories(path.getParent());

        // Write all lines to the file
        Files.write(path, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    public void appendToFile(String filePath, String line) throws IOException {
        Path path = Paths.get(filePath);

        // Create parent directories if they don't exist
        Files.createDirectories(path.getParent());

        // Append the line to the file
        Files.write(path, Collections.singletonList(line), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    public List<String> readFromFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);

        if (!Files.exists(path)) {
            return new ArrayList<>();
        }

        return Files.readAllLines(path);
    }

    public void updateLine(String filePath, String identifier, String newLine) throws IOException {
        Path path = Paths.get(filePath);

        if (!Files.exists(path)) {
            throw new FileNotFoundException("File not found: " + filePath);
        }

        List<String> lines = Files.readAllLines(path);
        List<String> updatedLines = lines.stream()
                .map(line -> line.startsWith(identifier) ? newLine : line)
                .collect(Collectors.toList());

        Files.write(path, updatedLines, StandardOpenOption.TRUNCATE_EXISTING);
    }

    public void deleteLine(String filePath, String identifier) throws IOException {
        Path path = Paths.get(filePath);

        if (!Files.exists(path)) {
            throw new FileNotFoundException("File not found: " + filePath);
        }

        List<String> lines = Files.readAllLines(path);
        List<String> updatedLines = lines.stream()
                .filter(line -> !line.startsWith(identifier))
                .collect(Collectors.toList());

        Files.write(path, updatedLines, StandardOpenOption.TRUNCATE_EXISTING);
    }
}
