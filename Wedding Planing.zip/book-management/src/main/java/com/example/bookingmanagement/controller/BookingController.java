//package com.example.bookingmanagement.controller;
//
//import com.example.bookingmanagement.model.Booking;
//import com.example.bookingmanagement.model.BookingType;
//import com.example.bookingmanagement.service.BookingService;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.format.annotation.DateTimeFormat;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;
//
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.NoSuchElementException;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//@Controller
//@RequestMapping("/bookings")
//public class BookingController {
//
//    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);
//
//    @Autowired
//    private BookingService bookingService;
//
//    @GetMapping
//    public String getAllBookings(Model model) {
//        List<Booking> bookings = bookingService.getAllBookings();
//        model.addAttribute("bookings", bookings);
//        return "booking-history";
//    }
//
//    @GetMapping("/user/{userId}")
//    public String getBookingsByUser(@PathVariable String userId, Model model) {
//        List<Booking> bookings = bookingService.getBookingsByUserId(userId);
//        model.addAttribute("bookings", bookings);
//        model.addAttribute("userId", userId);
//        return "booking-history";
//    }
//
//    @GetMapping("/vendor/{vendorId}")
//    public String getBookingsByVendor(@PathVariable String vendorId, Model model) {
//        List<Booking> bookings = bookingService.getBookingsByVendorId(vendorId);
//        model.addAttribute("bookings", bookings);
//        model.addAttribute("vendorId", vendorId);
//        return "booking-history";
//    }
//
//    // New method for showing the create booking form
//    @GetMapping("/new")
//    public String showCreateBookingForm(Model model) {
//        logger.info("Showing create booking form");
//        model.addAttribute("bookingTypes", BookingType.values());
//        return "create-booking";
//    }
//
//    // New method for creating a booking
//    @PostMapping("/create")
//    public String createBooking(
////            @RequestParam String userId,
////            @RequestParam String vendorId,
////            @RequestParam String vendorName,
////            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime bookingDateTime,
////            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime endDateTime,
////            @RequestParam BookingType bookingType,
////            @RequestParam double price,
////            RedirectAttributes redirectAttributes) {
//            @RequestParam String userId,
//            @RequestParam String vendorId,
//            @RequestParam String vendorName,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingDateTime,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDateTime,
//            @RequestParam BookingType bookingType,
//            @RequestParam double price,
//            RedirectAttributes redirectAttributes) {
//
//        try {
//            logger.info("Creating new booking for user: {}, vendor: {}", userId, vendorId);
//            Booking booking = new Booking(userId, vendorId, vendorName, bookingDateTime, endDateTime, bookingType, price);
//            Booking savedBooking = bookingService.createBooking(booking);
//            logger.info("Successfully created booking with ID: {}", savedBooking.getId());
//
//            redirectAttributes.addFlashAttribute("successMessage", "Booking created successfully!");
//            return "redirect:/bookings/confirmation/" + savedBooking.getId();
//        } catch (Exception e) {
//            logger.error("Failed to create booking", e);
//            redirectAttributes.addFlashAttribute("errorMessage", "Failed to create booking: " + e.getMessage());
//            return "redirect:/bookings/new";
//        }
//    }
//
//    @GetMapping("/{id}")
//    public String getBookingDetails(@PathVariable String id, Model model, RedirectAttributes redirectAttributes) {
//        try {
//            logger.info("Fetching booking details for ID: {}", id);
//            Booking booking = bookingService.getBookingById(id);
//            model.addAttribute("booking", booking);
//            return "booking-details";
//        } catch (NoSuchElementException e) {
//            logger.error("Booking not found with ID: {}", id);
//            redirectAttributes.addFlashAttribute("errorMessage", "Booking not found with ID: " + id);
//            return "redirect:/bookings";
//        }
//    }
//
//    // Updated method for showing the edit form
//    @GetMapping("/edit/{id}")
//    public String showEditForm(@PathVariable String id, Model model, RedirectAttributes redirectAttributes) {
//        try {
//            logger.info("Showing edit form for booking ID: {}", id);
//            Booking booking = bookingService.getBookingById(id);
//            model.addAttribute("booking", booking);
//            model.addAttribute("bookingTypes", BookingType.values());
//            return "edit-booking";
//        } catch (NoSuchElementException e) {
//            logger.error("Booking not found with ID: {}", id);
//            redirectAttributes.addFlashAttribute("errorMessage", "Booking not found with ID: " + id);
//            return "redirect:/bookings";
//        }
//    }
//
//    @PostMapping("/update")
//    public String updateBooking(
//            @RequestParam String id,
//            @RequestParam String userId,
//            @RequestParam String vendorId,
//            @RequestParam String vendorName,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingDateTime,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDateTime,
//            @RequestParam BookingType bookingType,
//            @RequestParam double price,
//            @RequestParam String status,
//            RedirectAttributes redirectAttributes) {
//
//        try {
//            logger.info("Updating booking with ID: {}", id);
//            Booking booking = new Booking(userId, vendorId, vendorName, bookingDateTime, endDateTime, bookingType, price);
//            booking.setId(id);
//            booking.setStatus(status);
//
//            bookingService.updateBooking(booking);
//            logger.info("Successfully updated booking with ID: {}", id);
//
//            redirectAttributes.addFlashAttribute("successMessage", "Booking updated successfully!");
//            return "redirect:/bookings";
//        } catch (Exception e) {
//            logger.error("Failed to update booking", e);
//            redirectAttributes.addFlashAttribute("errorMessage", "Failed to update booking: " + e.getMessage());
//            return "redirect:/bookings";
//        }
//    }
//
//    @GetMapping("/cancel/{id}")
//    public String cancelBooking(@PathVariable String id, RedirectAttributes redirectAttributes) {
//        try {
//            logger.info("Cancelling booking with ID: {}", id);
//            bookingService.cancelBooking(id);
//            logger.info("Successfully cancelled booking with ID: {}", id);
//
//            redirectAttributes.addFlashAttribute("successMessage", "Booking cancelled successfully!");
//        } catch (Exception e) {
//            logger.error("Failed to cancel booking", e);
//            redirectAttributes.addFlashAttribute("errorMessage", "Failed to cancel booking: " + e.getMessage());
//        }
//        return "redirect:/bookings";
//    }
//
//    @GetMapping("/confirm/{id}")
//    public String confirmBooking(
//            @PathVariable String id,
//            @RequestParam(defaultValue = "EMAIL") String confirmationType,
//            RedirectAttributes redirectAttributes) {
//
//        try {
//            logger.info("Confirming booking with ID: {} via {}", id, confirmationType);
//            bookingService.confirmBooking(id, confirmationType);
//            logger.info("Successfully confirmed booking with ID: {}", id);
//
//            redirectAttributes.addFlashAttribute("successMessage", "Booking confirmed successfully!");
//        } catch (Exception e) {
//            logger.error("Failed to confirm booking", e);
//            redirectAttributes.addFlashAttribute("errorMessage", "Failed to confirm booking: " + e.getMessage());
//        }
//        return "redirect:/bookings";
//    }
//
//    @GetMapping("/confirmation/{id}")
//    public String showConfirmationPage(@PathVariable String id, Model model, RedirectAttributes redirectAttributes) {
//        try {
//            logger.info("Showing confirmation page for booking ID: {}", id);
//            Booking booking = bookingService.getBookingById(id);
//            model.addAttribute("booking", booking);
//            return "booking-confirmation";
//        } catch (NoSuchElementException e) {
//            logger.error("Booking not found with ID: {}", id);
//            redirectAttributes.addFlashAttribute("errorMessage", "Booking not found with ID: " + id);
//            return "redirect:/bookings";
//        }
//    }
//
//    @ExceptionHandler(Exception.class)
//    public String handleException(Exception e, RedirectAttributes redirectAttributes) {
//        logger.error("Unhandled exception in BookingController", e);
//        redirectAttributes.addFlashAttribute("errorMessage", "An unexpected error occurred: " + e.getMessage());
//        return "redirect:/bookings";
//    }
//}


package com.example.bookingmanagement.controller;

import com.example.bookingmanagement.model.Booking;
import com.example.bookingmanagement.model.BookingType;
import com.example.bookingmanagement.service.BookingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
@RequestMapping("/bookings")
public class BookingController {

    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    @Autowired
    private BookingService bookingService;

    // Helper method to convert LocalDateTime to Date
    private Date convertToDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    @GetMapping
    public String getAllBookings(Model model) {
        List<Booking> bookings = bookingService.getAllBookings();
        model.addAttribute("bookings", bookings);
        return "booking-history";
    }

    @GetMapping("/user/{userId}")
    public String getBookingsByUser(@PathVariable String userId, Model model) {
        List<Booking> bookings = bookingService.getBookingsByUserId(userId);
        model.addAttribute("bookings", bookings);
        model.addAttribute("userId", userId);
        return "booking-history";
    }

    @GetMapping("/vendor/{vendorId}")
    public String getBookingsByVendor(@PathVariable String vendorId, Model model) {
        List<Booking> bookings = bookingService.getBookingsByVendorId(vendorId);
        model.addAttribute("bookings", bookings);
        model.addAttribute("vendorId", vendorId);
        return "booking-history";
    }

    // New method for showing the create booking form
    @GetMapping("/new")
    public String showCreateBookingForm(Model model) {
        logger.info("Showing create booking form");
        model.addAttribute("bookingTypes", BookingType.values());
        return "create-booking";
    }

    // New method for creating a booking
    @PostMapping("/create")
    public String createBooking(
            @RequestParam String userId,
            @RequestParam String vendorId,
            @RequestParam String vendorName,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingDateTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDateTime,
            @RequestParam BookingType bookingType,
            @RequestParam double price,
            RedirectAttributes redirectAttributes) {

        try {
            logger.info("Creating new booking for user: {}, vendor: {}", userId, vendorId);

            // Convert LocalDateTime to Date
            Date bookingDate = convertToDate(bookingDateTime);
            Date endDate = convertToDate(endDateTime);

            Booking booking = new Booking(userId, vendorId, vendorName, bookingDateTime, endDateTime, bookingType, price);
            Booking savedBooking = bookingService.createBooking(booking);
            logger.info("Successfully created booking with ID: {}", savedBooking.getId());

            redirectAttributes.addFlashAttribute("successMessage", "Booking created successfully!");
            return "redirect:/bookings/confirmation/" + savedBooking.getId();
        } catch (Exception e) {
            logger.error("Failed to create booking", e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to create booking: " + e.getMessage());
            return "redirect:/bookings/new";
        }
    }

    @GetMapping("/{id}")
    public String getBookingDetails(@PathVariable String id, Model model, RedirectAttributes redirectAttributes) {
        try {
            logger.info("Fetching booking details for ID: {}", id);
            Booking booking = bookingService.getBookingById(id);

            // Convert LocalDateTime to Date
            Date bookingDate = convertToDate(booking.getBookingDateTime());
            Date endDate = convertToDate(booking.getEndDateTime());
            model.addAttribute("bookingDate", bookingDate);
            model.addAttribute("endDate", endDate);
            model.addAttribute("booking", booking);

            return "booking-details";
        } catch (NoSuchElementException e) {
            logger.error("Booking not found with ID: {}", id);
            redirectAttributes.addFlashAttribute("errorMessage", "Booking not found with ID: " + id);
            return "redirect:/bookings";
        }
    }

    // Updated method for showing the edit form
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable String id, Model model, RedirectAttributes redirectAttributes) {
        try {
            logger.info("Showing edit form for booking ID: {}", id);
            Booking booking = bookingService.getBookingById(id);
            model.addAttribute("booking", booking);
            model.addAttribute("bookingTypes", BookingType.values());
            return "edit-booking";
        } catch (NoSuchElementException e) {
            logger.error("Booking not found with ID: {}", id);
            redirectAttributes.addFlashAttribute("errorMessage", "Booking not found with ID: " + id);
            return "redirect:/bookings";
        }
    }

    @PostMapping("/update")
    public String updateBooking(
            @RequestParam String id,
            @RequestParam String userId,
            @RequestParam String vendorId,
            @RequestParam String vendorName,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingDateTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDateTime,
            @RequestParam BookingType bookingType,
            @RequestParam double price,
            @RequestParam String status,
            RedirectAttributes redirectAttributes) {

        try {
            logger.info("Updating booking with ID: {}", id);

            // Convert LocalDateTime to Date
            Date bookingDate = convertToDate(bookingDateTime);
            Date endDate = convertToDate(endDateTime);

            Booking booking = new Booking(userId, vendorId, vendorName, bookingDateTime, endDateTime, bookingType, price);
            booking.setId(id);
            booking.setStatus(status);

            bookingService.updateBooking(booking);
            logger.info("Successfully updated booking with ID: {}", id);

            redirectAttributes.addFlashAttribute("successMessage", "Booking updated successfully!");
            return "redirect:/bookings";
        } catch (Exception e) {
            logger.error("Failed to update booking", e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to update booking: " + e.getMessage());
            return "redirect:/bookings";
        }
    }

    @GetMapping("/cancel/{id}")
    public String cancelBooking(@PathVariable String id, RedirectAttributes redirectAttributes) {
        try {
            logger.info("Cancelling booking with ID: {}", id);
            bookingService.cancelBooking(id);
            logger.info("Successfully cancelled booking with ID: {}", id);

            redirectAttributes.addFlashAttribute("successMessage", "Booking cancelled successfully!");
        } catch (Exception e) {
            logger.error("Failed to cancel booking", e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to cancel booking: " + e.getMessage());
        }
        return "redirect:/bookings";
    }

    @GetMapping("/confirm/{id}")
    public String confirmBooking(
            @PathVariable String id,
            @RequestParam(defaultValue = "EMAIL") String confirmationType,
            RedirectAttributes redirectAttributes) {

        try {
            logger.info("Confirming booking with ID: {} via {}", id, confirmationType);
            bookingService.confirmBooking(id, confirmationType);
            logger.info("Successfully confirmed booking with ID: {}", id);

            redirectAttributes.addFlashAttribute("successMessage", "Booking confirmed successfully!");
        } catch (Exception e) {
            logger.error("Failed to confirm booking", e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to confirm booking: " + e.getMessage());
        }
        return "redirect:/bookings";
    }

    @GetMapping("/confirmation/{id}")
    public String showConfirmationPage(@PathVariable String id, Model model, RedirectAttributes redirectAttributes) {
        try {
            logger.info("Showing confirmation page for booking ID: {}", id);
            Booking booking = bookingService.getBookingById(id);

            // Convert LocalDateTime to Date
            Date bookingDate = convertToDate(booking.getBookingDateTime());
            Date endDate = convertToDate(booking.getEndDateTime());
            model.addAttribute("bookingDate", bookingDate);
            model.addAttribute("endDate", endDate);
            model.addAttribute("booking", booking);

            return "booking-confirmation";
        } catch (NoSuchElementException e) {
            logger.error("Booking not found with ID: {}", id);
            redirectAttributes.addFlashAttribute("errorMessage", "Booking not found with ID: " + id);
            return "redirect:/bookings";
        }
    }

    // Global exception handler
    @ExceptionHandler(Exception.class)
    public String handleException(Exception e, RedirectAttributes redirectAttributes) {
        logger.error("Unhandled exception in BookingController", e);
        redirectAttributes.addFlashAttribute("errorMessage", "An unexpected error occurred: " + e.getMessage());
        return "redirect:/bookings";
    }
}
