package com.example.bookingmanagement.service;

import com.example.bookingmanagement.model.Booking;
import java.util.List;

public interface BookingService {
    Booking createBooking(Booking booking);
    Booking getBookingById(String id);
    List<Booking> getAllBookings();
    List<Booking> getBookingsByUserId(String userId);
    List<Booking> getBookingsByVendorId(String vendorId);
    Booking updateBooking(Booking booking);
    void cancelBooking(String id);
    void confirmBooking(String id, String confirmationType);
}
