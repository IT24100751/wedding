package com.example.bookingmanagement.service.confirmation;

import com.example.bookingmanagement.model.Booking;
import org.springframework.stereotype.Component;

@Component
public class EmailConfirmationStrategy implements BookingConfirmationStrategy {
    
    @Override
    public void sendConfirmation(Booking booking) {
        // In a real application, this would send an email
        System.out.println("Sending email confirmation for booking: " + booking.getId());
        System.out.println("To: " + booking.getUserId());
        System.out.println("Subject: Booking Confirmation");
        System.out.println("Body: Your booking with " + booking.getVendorName() + 
                " on " + booking.getBookingDateTime() + " has been confirmed.");
    }
}
