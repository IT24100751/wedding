package com.example.bookingmanagement.service.confirmation;

import com.example.bookingmanagement.model.Booking;

// Abstraction: Interface for different confirmation strategies
public interface BookingConfirmationStrategy {
    void sendConfirmation(Booking booking);
}
