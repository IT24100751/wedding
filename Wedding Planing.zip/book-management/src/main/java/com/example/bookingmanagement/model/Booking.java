package com.example.bookingmanagement.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

// Encapsulation: All fields are private with getters and setters
public class Booking {
    private String id;
    private String userId;
    private String vendorId;
    private String vendorName;
    private LocalDateTime bookingDateTime;
    private LocalDateTime endDateTime;
    private BookingType bookingType;
    private double price;
    private String status; // PENDING, CONFIRMED, CANCELLED
    
    // Default constructor
    public Booking() {
        this.id = UUID.randomUUID().toString();
        this.status = "PENDING";
    }
    
    // Parameterized constructor
    public Booking(String userId, String vendorId, String vendorName, 
                  LocalDateTime bookingDateTime, LocalDateTime endDateTime, 
                  BookingType bookingType, double price) {
        this.id = UUID.randomUUID().toString();
        this.userId = userId;
        this.vendorId = vendorId;
        this.vendorName = vendorName;
        this.bookingDateTime = bookingDateTime;
        this.endDateTime = endDateTime;
        this.bookingType = bookingType;
        this.price = price;
        this.status = "PENDING";
    }
    
    // Getters and Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getVendorId() {
        return vendorId;
    }
    
    public void setVendorId(String vendorId) {
        this.vendorId = vendorId;
    }
    
    public String getVendorName() {
        return vendorName;
    }
    
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }
    
    public LocalDateTime getBookingDateTime() {
        return bookingDateTime;
    }
    
    public void setBookingDateTime(LocalDateTime bookingDateTime) {
        this.bookingDateTime = bookingDateTime;
    }
    
    public LocalDateTime getEndDateTime() {
        return endDateTime;
    }
    
    public void setEndDateTime(LocalDateTime endDateTime) {
        this.endDateTime = endDateTime;
    }
    
    public BookingType getBookingType() {
        return bookingType;
    }
    
    public void setBookingType(BookingType bookingType) {
        this.bookingType = bookingType;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    // Abstraction: Validation methods
    public boolean isValid() {
        return userId != null && !userId.isEmpty() &&
               vendorId != null && !vendorId.isEmpty() &&
               bookingDateTime != null &&
               endDateTime != null &&
               bookingDateTime.isBefore(endDateTime) &&
               price >= 0;
    }
    
    public boolean isOverlapping(Booking other) {
        return (this.bookingDateTime.isBefore(other.endDateTime) && 
                this.endDateTime.isAfter(other.bookingDateTime)) &&
                this.vendorId.equals(other.vendorId);
    }
    
    // Convert to string format for file storage
    public String toFileString() {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        return String.join("|", 
            id,
            userId,
            vendorId,
            vendorName,
            bookingDateTime.format(formatter),
            endDateTime.format(formatter),
            bookingType.name(),
            String.valueOf(price),
            status
        );
    }
    
    // Create booking from file string
    public static Booking fromFileString(String fileString) {
        String[] parts = fileString.split("\\|");
        if (parts.length != 9) {
            throw new IllegalArgumentException("Invalid booking string format");
        }
        
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        Booking booking = new Booking();
        booking.setId(parts[0]);
        booking.setUserId(parts[1]);
        booking.setVendorId(parts[2]);
        booking.setVendorName(parts[3]);
        booking.setBookingDateTime(LocalDateTime.parse(parts[4], formatter));
        booking.setEndDateTime(LocalDateTime.parse(parts[5], formatter));
        booking.setBookingType(BookingType.valueOf(parts[6]));
        booking.setPrice(Double.parseDouble(parts[7]));
        booking.setStatus(parts[8]);
        
        return booking;
    }
    
    @Override
    public String toString() {
        return "Booking{" +
                "id='" + id + '\'' +
                ", userId='" + userId + '\'' +
                ", vendorId='" + vendorId + '\'' +
                ", vendorName='" + vendorName + '\'' +
                ", bookingDateTime=" + bookingDateTime +
                ", endDateTime=" + endDateTime +
                ", bookingType=" + bookingType +
                ", price=" + price +
                ", status='" + status + '\'' +
                '}';
    }
}
