package com.example.bookingmanagement.service;

import com.example.bookingmanagement.model.Booking;
import com.example.bookingmanagement.repository.BookingRepository;
import com.example.bookingmanagement.service.confirmation.BookingConfirmationStrategy;
import com.example.bookingmanagement.service.confirmation.EmailConfirmationStrategy;
import com.example.bookingmanagement.service.confirmation.SMSConfirmationStrategy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class BookingServiceImpl implements BookingService {
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private EmailConfirmationStrategy emailConfirmationStrategy;
    
    @Autowired
    private SMSConfirmationStrategy smsConfirmationStrategy;
    
    @Override
    public Booking createBooking(Booking booking) {
        if (!booking.isValid()) {
            throw new IllegalArgumentException("Invalid booking details");
        }
        
        // Check for overlapping bookings
        List<Booking> existingBookings = bookingRepository.findByVendorId(booking.getVendorId());
        for (Booking existingBooking : existingBookings) {
            if (booking.isOverlapping(existingBooking) && 
                !existingBooking.getStatus().equals("CANCELLED")) {
                throw new IllegalStateException("Booking overlaps with an existing booking");
            }
        }
        
        return bookingRepository.save(booking);
    }
    
    @Override
    public Booking getBookingById(String id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Booking not found with ID: " + id));
    }
    
    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
    
    @Override
    public List<Booking> getBookingsByUserId(String userId) {
        return bookingRepository.findByUserId(userId);
    }
    
    @Override
    public List<Booking> getBookingsByVendorId(String vendorId) {
        return bookingRepository.findByVendorId(vendorId);
    }
    
    @Override
    public Booking updateBooking(Booking booking) {
        Booking existingBooking = getBookingById(booking.getId());
        
        if (!booking.isValid()) {
            throw new IllegalArgumentException("Invalid booking details");
        }
        
        // Check for overlapping bookings
        List<Booking> existingBookings = bookingRepository.findByVendorId(booking.getVendorId());
        for (Booking otherBooking : existingBookings) {
            if (!otherBooking.getId().equals(booking.getId()) && 
                booking.isOverlapping(otherBooking) && 
                !otherBooking.getStatus().equals("CANCELLED")) {
                throw new IllegalStateException("Updated booking overlaps with an existing booking");
            }
        }
        
        bookingRepository.update(booking);
        return booking;
    }
    
    @Override
    public void cancelBooking(String id) {
        Booking booking = getBookingById(id);
        booking.setStatus("CANCELLED");
        bookingRepository.update(booking);
    }
    
    @Override
    public void confirmBooking(String id, String confirmationType) {
        Booking booking = getBookingById(id);
        booking.setStatus("CONFIRMED");
        bookingRepository.update(booking);
        
        // Polymorphism: Different confirmation strategies
        BookingConfirmationStrategy confirmationStrategy;
        
        if ("SMS".equalsIgnoreCase(confirmationType)) {
            confirmationStrategy = smsConfirmationStrategy;
        } else {
            confirmationStrategy = emailConfirmationStrategy;
        }
        
        confirmationStrategy.sendConfirmation(booking);
    }
}
