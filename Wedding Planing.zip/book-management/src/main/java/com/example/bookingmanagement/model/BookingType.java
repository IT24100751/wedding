package com.example.bookingmanagement.model;

public enum BookingType {
    HOURLY("Hourly"),
    HALF_DAY("Half Day"),
    FULL_DAY("Full Day"),
    WEEKLY("Weekly");
    
    private final String displayName;
    
    BookingType(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() {
        return displayName;
    }
}
