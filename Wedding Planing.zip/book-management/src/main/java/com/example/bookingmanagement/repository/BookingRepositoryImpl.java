package com.example.bookingmanagement.repository;

import com.example.bookingmanagement.model.Booking;
import com.example.bookingmanagement.util.FileHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Repository
public class BookingRepositoryImpl implements BookingRepository {

    private static final Logger logger = LoggerFactory.getLogger(BookingRepositoryImpl.class);

    @Value("${app.data.directory:data}")
    private String dataDirectory;

    private String bookingsFilePath;

    @Autowired
    private FileHandler fileHandler;

    @PostConstruct
    public void init() {
        // Ensure data directory exists
        File directory = new File(dataDirectory);
        if (!directory.exists()) {
            directory.mkdirs();
            logger.info("Created data directory: {}", directory.getAbsolutePath());
        }

        // Set the full path to the bookings file
        bookingsFilePath = dataDirectory + File.separator + "bookings.txt";
        logger.info("Bookings will be stored at: {}", bookingsFilePath);

        // Create the file if it doesn't exist
        try {
            File bookingsFile = new File(bookingsFilePath);
            if (!bookingsFile.exists()) {
                bookingsFile.createNewFile();
                logger.info("Created bookings file: {}", bookingsFile.getAbsolutePath());
            }
        } catch (IOException e) {
            logger.error("Failed to create bookings file", e);
        }
    }

    @Override
    public Booking save(Booking booking) {
        try {
            logger.debug("Saving booking: {}", booking);
            fileHandler.appendToFile(bookingsFilePath, booking.toFileString());
            logger.info("Successfully saved booking with ID: {}", booking.getId());
            return booking;
        } catch (IOException e) {
            logger.error("Failed to save booking", e);
            throw new RuntimeException("Failed to save booking", e);
        }
    }

    @Override
    public Optional<Booking> findById(String id) {
        try {
            logger.debug("Finding booking by ID: {}", id);
            List<String> lines = fileHandler.readFromFile(bookingsFilePath);
            logger.debug("Read {} lines from bookings file", lines.size());

            for (String line : lines) {
                try {
                    Booking booking = Booking.fromFileString(line);
                    if (booking.getId().equals(id)) {
                        logger.info("Found booking with ID: {}", id);
                        return Optional.of(booking);
                    }
                } catch (Exception e) {
                    logger.warn("Error parsing booking line: {}", line, e);
                }
            }

            logger.warn("Booking not found with ID: {}", id);
            return Optional.empty();
        } catch (IOException e) {
            logger.error("Failed to find booking by ID", e);
            throw new RuntimeException("Failed to find booking by ID", e);
        }
    }

    @Override
    public List<Booking> findAll() {
        try {
            logger.debug("Finding all bookings");
            List<String> lines = fileHandler.readFromFile(bookingsFilePath);
            logger.debug("Read {} lines from bookings file", lines.size());

            List<Booking> bookings = new ArrayList<>();
            for (String line : lines) {
                try {
                    bookings.add(Booking.fromFileString(line));
                } catch (Exception e) {
                    logger.warn("Error parsing booking line: {}", line, e);
                }
            }

            logger.info("Found {} bookings", bookings.size());
            return bookings;
        } catch (IOException e) {
            logger.error("Failed to find all bookings", e);
            throw new RuntimeException("Failed to find all bookings", e);
        }
    }

    @Override
    public List<Booking> findByUserId(String userId) {
        try {
            logger.debug("Finding bookings by user ID: {}", userId);
            return findAll().stream()
                    .filter(booking -> booking.getUserId().equals(userId))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Failed to find bookings by user ID", e);
            throw new RuntimeException("Failed to find bookings by user ID", e);
        }
    }

    @Override
    public List<Booking> findByVendorId(String vendorId) {
        try {
            logger.debug("Finding bookings by vendor ID: {}", vendorId);
            return findAll().stream()
                    .filter(booking -> booking.getVendorId().equals(vendorId))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Failed to find bookings by vendor ID", e);
            throw new RuntimeException("Failed to find bookings by vendor ID", e);
        }
    }

    @Override
    public void update(Booking booking) {
        try {
            logger.debug("Updating booking: {}", booking);
            List<Booking> bookings = findAll();
            boolean found = false;

            List<String> updatedLines = new ArrayList<>();
            for (Booking existingBooking : bookings) {
                if (existingBooking.getId().equals(booking.getId())) {
                    updatedLines.add(booking.toFileString());
                    found = true;
                    logger.debug("Found and updated booking with ID: {}", booking.getId());
                } else {
                    updatedLines.add(existingBooking.toFileString());
                }
            }

            if (!found) {
                logger.warn("Booking not found for update, adding as new: {}", booking.getId());
                updatedLines.add(booking.toFileString());
            }

            fileHandler.writeToFile(bookingsFilePath, updatedLines);
            logger.info("Successfully updated booking with ID: {}", booking.getId());
        } catch (IOException e) {
            logger.error("Failed to update booking", e);
            throw new RuntimeException("Failed to update booking", e);
        }
    }

    @Override
    public void deleteById(String id) {
        try {
            logger.debug("Deleting booking by ID: {}", id);
            List<Booking> bookings = findAll();
            List<String> updatedLines = bookings.stream()
                    .filter(booking -> !booking.getId().equals(id))
                    .map(Booking::toFileString)
                    .collect(Collectors.toList());

            fileHandler.writeToFile(bookingsFilePath, updatedLines);
            logger.info("Successfully deleted booking with ID: {}", id);
        } catch (IOException e) {
            logger.error("Failed to delete booking", e);
            throw new RuntimeException("Failed to delete booking", e);
        }
    }
}
