package com.example.bookingmanagement.repository;

import com.example.bookingmanagement.model.Booking;
import java.util.List;
import java.util.Optional;

public interface BookingRepository {
    Booking save(Booking booking);
    Optional<Booking> findById(String id);
    List<Booking> findAll();
    List<Booking> findByUserId(String userId);
    List<Booking> findByVendorId(String vendorId);
    void update(Booking booking);
    void deleteById(String id);
}
