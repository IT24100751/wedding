package com.wedding.util;

import com.wedding.model.Vendor;

public class VendorNode {
    private Vendor vendor;
    private VendorNode next;

    public VendorNode(Vendor vendor) {
        this.vendor = vendor;
        this.next = null;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    public VendorNode getNext() {
        return next;
    }

    public void setNext(VendorNode next) {
        this.next = next;
    }
}