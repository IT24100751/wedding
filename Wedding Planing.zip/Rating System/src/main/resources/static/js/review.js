// JavaScript functions for the Review Rating System

// Toggle verified/unverified options on edit form
function toggleReviewOptions() {
  const verifiedCheckbox = document.getElementById("verified")
  const verifiedOptions = document.getElementById("verifiedOptions")
  const unverifiedOptions = document.getElementById("unverifiedOptions")

  if (verifiedCheckbox.checked) {
    verifiedOptions.style.display = "block"
    unverifiedOptions.style.display = "none"
  } else {
    verifiedOptions.style.display = "none"
    unverifiedOptions.style.display = "block"
  }
}

// Toggle flag reason field
function toggleFlagReason() {
  const flaggedCheckbox = document.getElementById("flagged")
  const flagReasonGroup = document.getElementById("flagReasonGroup")

  if (flaggedCheckbox.checked) {
    flagReasonGroup.style.display = "block"
  } else {
    flagReasonGroup.style.display = "none"
  }
}

// Confirm delete
function confirmDelete(reviewId) {
  if (confirm("Are you sure you want to delete this review?")) {
    window.location.href = `/reviews/delete/${reviewId}`
  }
}

// Initialize event listeners when document is ready
document.addEventListener("DOMContentLoaded", () => {
  // Add event listeners if elements exist
  const verifiedCheckbox = document.getElementById("verified")
  if (verifiedCheckbox) {
    verifiedCheckbox.addEventListener("change", toggleReviewOptions)
  }

  const flaggedCheckbox = document.getElementById("flagged")
  if (flaggedCheckbox) {
    flaggedCheckbox.addEventListener("change", toggleFlagReason)
  }
})
